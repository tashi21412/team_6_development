window.onload = function(){
	
//		document.getElementById("register").addEventListener("click",signUp, false);
}

function signUp(){




       

     



}