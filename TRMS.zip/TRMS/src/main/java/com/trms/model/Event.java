package com.trms.model;

public class Event {

	private long UNIVERSITY_COURSE = 80;
	
	private long SEMINAR = 60;
	
	private long CERTIFICATION_PREP_CLASS = 75;
	
	private long CERTIFICATION = 100;
	
	private long TECHINICAL_TRAINING = 90;
	
	private long OTHER = 30;
	
}